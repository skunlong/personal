import React from 'react';
import ListItem from './ListItem';

const LocationList = ({locations}) => {
	const renderedList = locations.map((location) => {
		return <ListItem key= {location.id} location={location}/>
	});

	return (
		<tbody>
			{renderedList}
		</tbody>
	);

}

export default LocationList;