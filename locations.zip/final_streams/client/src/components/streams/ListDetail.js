import React, {useEffect, useState} from 'react';
import {useParams} from 'react-router-dom';
import detailApi from '../../apis/streams';
import LeftPane from './LeftPane';
import BreadCrumb from './BreadCrumb';
import { useFormik } from 'formik';
import './ListItem.css';
import {ReactComponent as LocationPin} from './location-pin.svg';
import {ReactComponent as PhoneLogo} from './phone-logo.svg';


const ListDetail = () => {
	const {id} = useParams();
	const [detail, setDetail] = useState([]);
	const [isEdit, setEdit] = useState(false);;
	const [updated, setUpdated] = useState(false)

	useEffect(()=> {
		getDetail(id);
	}, [updated, id]);

	const getDetail = async (id) => {
		const response = await detailApi.get(`/locations/${id}`);
		setDetail(response.data);
		setUpdated(false);
	};

	const tagClass = detail.tags && detail.tags.length ? "ui label" : "";

	const toggleEdit = () => {
		setEdit(true);
	};

    const validate = (values) => {
    	const phoneFormat = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
   		const errors = {};
	   	if (!values.title) {
	     	errors.name = '*Required';
	    }
	 
	   	if (!values.address) {
	     	errors.address = '*Required';
	   	} 
	 
	   	if (!values.phone) {
	     	errors.phone = '*Required';
	   	} else if (values.phone.match(/\d/g).length !== 10 || !phoneFormat.test(values.phone)) {
	     	errors.phone = 'Invalid phone number';
	   	}
	 
	   return errors;
 	};

 	const getInitials = () => {
 		return {
 			title: detail.title,
 			address: detail.address,
 			phone: detail.phone,
 			tags: detail.tags ? detail.tags : ''
 		};
 	};

 	const updateDetail = async(formValues) => {
		const response = await detailApi.put(`/locations/${id}`, formValues);
		setEdit(false);
		setUpdated(true);

	}

	const cancel = () => {
		setEdit(false);
	}


   	const formik = useFormik({
     	initialValues: getInitials(),
     	enableReinitialize: true,
     	validate,
     	onSubmit: (values) => {
       		updateDetail(values);
     	},
  	 });

	const renderForm = () => {
		if (isEdit) {
			return (
			<div>
				<BreadCrumb currentLoc={`location / ${id}`}/>	
				<div className="form-container">
							<form onSubmit={formik.handleSubmit} className="ui form create">
									<div className="ui segment create">
									  	<div className="field">
			    							<label><h4>Name</h4></label>
			    							{formik.errors.name ? <h5 className="ui header red">{formik.errors.name}</h5> : null}
											<input type="text" name="title" onChange={formik.handleChange} value={formik.values.title} default={detail.title}/>
										</div>
										<div className="field">
											<label><h4>Address</h4></label>
											{formik.errors.address ? <h5 className="ui header red ">{formik.errors.address}</h5> : null}
											<input type="text" name="address" onChange={formik.handleChange} value={formik.values.address}/>
										</div>
										<div className="field">
											<label><h4>Phone</h4></label>
											{formik.errors.phone ? <h5 className="ui header red">{formik.errors.phone}</h5> : null}
											<input type="text" name="phone" onChange={formik.handleChange} value={formik.values.phone}/>
										</div>
										<div className="field">
											<label><h4>Tags</h4></label>
											<input type="text" name="tags" onChange={formik.handleChange} value={formik.values.tags}/>
										</div>
										 <button className="ui button add" type="submit">Update</button>
										 <button className="ui button add cancel" onClick={cancel}>Cancel</button>
									</div>
							</form>
				</div>
			</div>
			)
		}
		else {
			return (
				<div>
					<BreadCrumb currentLoc={`location / ${id}`}/>
					<div className="form-container">
						<div className="ui form create">
							<div className="ui segment detail">
									<div className="card">
										<h4 className="ui header">{detail.title}</h4>
										<p>
										     <span className="location-pin"><LocationPin /></span>
		         							 {detail.address}
										</p>
										<p>
										     <span className="location-pin"><PhoneLogo /></span>
		         							 {detail.phone}
										</p>
										<div className= {tagClass}>
											<p>{detail.tags}</p>
										</div>
										<p><button className="ui button add edit" onClick={toggleEdit}>Edit</button></p>
									</div>
							</div>
						</div>
					</div>
				</div>
			)
		}
	}
	
	return (
		<div>
			<LeftPane />
			<div className="pusher form">
				{renderForm()}
			</div>
		</div>
	);
};

export default ListDetail;