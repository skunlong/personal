import React, {useState, useEffect } from 'react';
import SearchBar from './SearchBar'
import LocationList from './LocationList';
import useLocation from '../hooks/useLocation';
import LeftPane from './LeftPane';
import {useHistory} from 'react-router-dom';
import InfiniteScroll from 'react-infinite-scroll-component';
import './ListItem.css';


const Home = () => {
  	
	const [locations, search] = useLocation('');
	const [page, setPage] = useState(1);
	const history = useHistory();

	useEffect(()=> {
		return null;
	}, [locations]);

	const create = () => {
		history.push(`/create`);
	};

	const fetchMore = () => {
	    setTimeout(() => {
			search('', page+1);
	    }, 1500);
	    setPage(page+1);
	};

	return (
			<div className="ui container main">
				<LeftPane />
				<div className="ui top fixed borderless inverted menu home">
						<div className="left item inverted" style={{color:'#000000'}}>
							<h3>Locations</h3>
						</div>
						<div className="right item search">
							<SearchBar onFormSubmit={search}/>
						</div>
						<div className=" left item">
							<button className="ui button add" onClick={create}>Add new location</button>
						</div>
				</div>
				<div className = "pusher main">
					<InfiniteScroll
						dataLength={locations.length}
						next={fetchMore}
						hasMore={true}
					>
						<table className = "ui basic table main">
							<thead>
								<tr>
									<th>Name</th>
									<th>Address</th>
									<th>Phone</th>
									<th>Tags</th>
								</tr>
							</thead>
								<LocationList 
										locations={locations}
								/>
						</table>
					</InfiniteScroll>
				</div>
			</div>
		);
};

export default Home;
