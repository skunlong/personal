import React from 'react';
import detailApi from '../../apis/streams';
import {useHistory} from 'react-router-dom';
import { useFormik } from 'formik';
import './ListItem.css';
import LeftPane from './LeftPane';
import BreadCrumb from './BreadCrumb';


const CreateLocation = () => {

	const history = useHistory();

   	const validate = (values) => {
   		const phoneFormat = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
   		const errors = {};
	   	if (!values.title) {
	     	errors.name = '*Required';
	    }
	 
	   	if (!values.address) {
	     	errors.address = '*Required';
	   	} 
	 
	   	if (!values.phone) {
	     	errors.phone = '*Required';
	   	} else if (values.phone.match(/\d/g).length !== 10 || !phoneFormat.test(values.phone)) {
	     	errors.phone = 'Invalid phone number';
	   	}
	 
	   return errors;
 	};


   	const formik = useFormik({
     	initialValues: {
       		email: '',
     	},
     	validate,
     	onSubmit: values => {
       		newLoc(values);
     	},
  	 });

	const newLoc = async(formValues) => {
		const response = await detailApi.post('/locations', formValues);
		if (response && response.data) {

			history.push(`/location/${response.data.id}`);
		}
	}

	return (	
			<div>
				<LeftPane />
				<div className="pusher form">
					<BreadCrumb currentLoc='create'/>	
					<div className="form-container">
						<form className="ui form create" onSubmit={formik.handleSubmit}>
								<div className="ui segment create">
								  	<div className="field">
		    							<label><h4>Name</h4></label>
		    							{formik.errors.name ? <h5 className="ui header red">{formik.errors.name}</h5> : null}
										<input type="text" name="title" onChange={formik.handleChange} value={formik.values.title}/>
									</div>
									<div className="field">
										<label><h4>Address</h4></label>
										{formik.errors.address ? <h5 className="ui header red ">{formik.errors.address}</h5> : null}
										<input type="text" name="address" onChange={formik.handleChange} value={formik.values.address}/>
									</div>
									<div className="field">
										<label><h4>Phone</h4></label>
										{formik.errors.phone ? <h5 className="ui header red">{formik.errors.phone}</h5> : null}
										<input type="text" name="phone" onChange={formik.handleChange} value={formik.values.phone}/>
									</div>
									<div className="field">
										<label><h4>Tags</h4></label>
										<input type="text" name="tags" onChange={formik.handleChange} value={formik.values.tags}/>
									</div>
									 <button type="submit" className="ui button add">Create</button>
								</div>
						</form>
					</div>
				</div>
			</div>
	);
}

export default CreateLocation;