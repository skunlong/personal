import React, {useState, useEffect } from 'react';
import SearchBar from './SearchBar'
import LocationList from './LocationList';
import useLocation from '../hooks/useLocation';
import LeftPane from './LeftPane';
import {useHistory} from 'react-router-dom';
import './ListItem.css';


const Home = () => {
  	
  	const [selectedLocation, setSelectedLocation] = useState(null);
	const [locations, search] = useLocation('');
	const history = useHistory();

	useEffect(()=> {
		setSelectedLocation(locations[0]);
	}, [locations]);

	const create = () => {
		history.push(`/create`);
	};

	return (
			<div className="ui container main">
				<LeftPane />
				<div className="ui top fixed menu borderless home">
						<div className=" left item">
							<h3>Locations</h3>
						</div>
						<div className="right item search">
							<SearchBar onFormSubmit={search}/>
						</div>
						<div className=" left item">
							<button className="ui button add" onClick={create}>Add new location</button>
						</div>
				</div>
				<div className = "pusher main">
					<table className = "ui basic table main">
						<thead>
							<tr>
								<th>Name</th>
								<th>Address</th>
								<th>Phone</th>
								<th>Tags</th>
							</tr>
						</thead>
						<LocationList 
								locations= {locations}
						/>
					</table>
				</div>
			</div>
		);
};

export default Home;
