import './ListItem.css';
import React, {useState} from 'react';
import {useHistory} from 'react-router-dom';
import {ReactComponent as LocationPin} from './location-pin.svg';
import {ReactComponent as PhoneLogo} from './phone-logo.svg';

const ListItem = ({ location}) => {

  const history = useHistory();
  const [id, setId] = useState(location.id);

  const tagClass = location.tags && location.tags.length ? "ui label" : "";

  const handleDetail = (e) => {

  	id && history.push(`/location/${id}`);
  };
  
  return (
    <tr onClick={handleDetail}>
    	<td>{location.title}</td>
      <td>
          <span className="location-pin"><LocationPin /></span>
          {location.address}
    	</td>
      <td>
          <span className="location-pin"><PhoneLogo /></span>
          {location.phone}
      </td>
      <td>
    	<div className= {tagClass}>{location.tags}</div>
      </td>
    </tr>
  );
};

export default ListItem;