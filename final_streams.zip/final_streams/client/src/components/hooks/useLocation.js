import React, {useState, useEffect} from 'react';
import fetcthLocs from '../../apis/streams';

const useLocation = (defaultSearchTerm) => {
	const [locations, setLocations] = useState([]);

	useEffect(() => {

		search(defaultSearchTerm);

	}, [defaultSearchTerm]);


	const search = async (term) => {

		let response = null;
		if (term.length) {
			 response = await fetcthLocs.get('/locations', {
				params: {
					title_like: term
				},
			});
		}
		else {
			 response = await fetcthLocs.get('/locations');
		}
		
		if (response) {
			setLocations(response.data);
		}
	};

	return [locations, search]

};

export default useLocation;