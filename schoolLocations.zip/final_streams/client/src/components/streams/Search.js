const Search = () => {

	const [locations, setLocations] = useState('');

	const {filter} = useParams();

	useEffect(()=> {
		filterSearch(filter);
	}, [filter]);

	const filterSearch = async (term) => {
		const response = await fetcthLocs.get('/locations', {
			params: {
				q:term
			},
		});
		setLocations(response.data);
	};

	return (
			<div className="ui container">
				<SearchBar setFilter={setFilter}/>
				<div className = "ui grid">
					<div className= "ui row">
						<div className ="eleven wide column">
						</div>
						<div className="five wide column">
							<LocationList 
								locations= {locations}
							/>
						</div>
					</div>
				</div>
			</div>
	);
};
export default Search;