import {useHistory} from 'react-router-dom';

const BreadCrumb = ({currentLoc}) => {

	const history = useHistory();

	const goHome = () => {
			history.push('/');
	};

	return (
		<div className="ui breadcrumb main">
			<a className="section" onClick={goHome}>Home</a>
			<span className="divider">/</span>
			<span className="section">{currentLoc}</span>
		</div>
	)
};

export default BreadCrumb;