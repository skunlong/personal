import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import Home from './streams/Home';
import ListDetail from './streams/ListDetail';
import CreateLocation from './streams/CreateLocation';

const App = () => {
  return (
    <div className="ui container">
      <BrowserRouter>
        <div>

          <Route path="/" exact component={Home} />
          <Route path="/location/:id">
            <ListDetail />
          </Route>
          <Route path="/search/:term">
            <ListDetail />
          </Route>
          <Route path="/create">
            <CreateLocation />
          </Route>

        </div>
      </BrowserRouter>
    </div>
  );
};

export default App;
