import React, { useState } from 'react';

const SearchBar = ({ onFormSubmit }) => {

  const [term, setTerm] = useState('');

  const startSearch = (term) => {
  	setTerm(term);
  	if(term.length >=2) {
  		onFormSubmit(term);
  	}
  	if (term.length==0) {
  		onFormSubmit(term);
  	}
  };

  return (
    <div className="ui search focus">
      <div className="ui icon input search">
            <input
              className="prompt"
              type="text"
              value={term}
              placeholder="Location name"
              onChange={(event) => startSearch(event.target.value)}
            />
            <i className="search icon"></i>
      </div>
    </div>
  );
};

export default SearchBar;