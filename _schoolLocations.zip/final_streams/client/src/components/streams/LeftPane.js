import React from 'react';
import './ListItem.css';
import {ReactComponent as Logo} from './locations.svg';
import {ReactComponent as Heart} from './heart-logo.svg';
import {ReactComponent as Profile} from './profile-icon.svg';
import {useHistory} from 'react-router-dom';

const LeftPane = () => {

	const history = useHistory();

	const goHome = () => {
		history.push(`/`);
	};

	return (
			<div className="ui visible left thin sidebar vertical menu home">
					<div className = "heart-logo">
						<Heart />
					</div>
					<div className = "location-logo" onClick={goHome}>
						<Logo />
						<p>Locations</p>
					</div>
					<div className = "profile">
						<Profile />
						<p>John Doe</p>
					</div>
			</div>
	);
};

export default LeftPane;