import React, {useState, useEffect} from 'react';
import fetcthLocs from '../../apis/streams';

const useLocation = ({defaultSearchTerm}) => {
	const [locations, setLocations] = useState([]);

	useEffect(() => {

		search(defaultSearchTerm);

	}, [defaultSearchTerm]);


	const search = async (term, page=1) => {

		let response = null;
		if (term && term.length) {
			 response = await fetcthLocs.get('/locations', {
				params: {
					title_like: term
				},
			});
		}
		else {
			 response = await fetcthLocs.get('/locations', {
			 	params: {
			 		_limit: 12,
			 		_page: page
			 	}
			 });
		}
		
		if (response) {
			let result = [];
			if (page!==1) {
				result = locations.concat(response.data)
			} else {
				result = response.data
			}

			setLocations(result);

		}
	};

	return [locations, search]

};

export default useLocation;